# Dharma Diary: Daily Reflections & The 18 Parvas of Mahabharata

A personal daily reflection journal and life-strategy companion inspired by the **18 Parvas of the Mahabharata** and the **Bhagavad Gita**.

Write your daily thoughts, struggles, dilemmas, or triumphs. The intelligent client-side Oracle analyzes your entry, maps it to its corresponding Parva of the Mahabharata, delivers empathetic counsel or heartfelt appreciation, and provides an authentic Sanskrit verse from Sri Krishna with its practical life takeaway.

---

## Key Features

1. **Daily Life Strategy Journal:**
   * Record thoughts, work challenges, moral dilemmas, relationship moments, or personal realizations.
   * Tag entries with emotional states (🎯 Determined, ⚔️ Conflicted, 🌧️ Overwhelmed, 🧘 Peaceful, 🏆 Triumphant, 🙏 Grateful, 🌿 Hopeful).
   * Categorize across Career & Studies, Relationships, Inner Peace, Ethical Dilemmas, Habits, and Personal Growth.

2. **The 18 Parvas Semantic Mirror:**
   * Matches your daily experience against the corresponding book of the Mahabharata:
     * **Adi Parva:** Foundations, origins, and new beginnings.
     * **Sabha Parva:** Peer pressure, ego, and toxic games.
     * **Vana Parva:** Exile, waiting, resilience, and solitude.
     * **Virata Parva:** Humility, staying undercover, and being underestimated.
     * **Udyoga Parva:** Preparation, diplomacy, and big crossroads.
     * **Bhishma Parva:** Moral dilemmas, inner duty, and the battlefield of the mind.
     * **Drona Parva:** High-pressure situations, breaking through complex challenges, and sacrifice.
     * **Karna Parva:** Destiny, character, self-worth, and past wounds.
     * **Shalya Parva:** The final stretch, fatigue near the finish line, and mastering stubbornness.
     * **Sauptika Parva:** Resisting vengeance, unfair attacks, and trauma healing.
     * **Stri Parva:** Grief, lamentation, and the strength of vulnerability.
     * **Shanti Parva:** Peace after the storm, mentorship, and restorative calm.
     * **Anushasana Parva:** Daily discipline, quiet habits, and good karma.
     * **Ashwamedhika Parva:** Rebuilding after ruin and self-renewal.
     * **Ashramavasika Parva:** Letting go gracefully and passing the torch.
     * **Mausala Parva:** Humility and the impermanence of worldly vanity.
     * **Mahaprasthanika Parva:** Standing alone for truth and lifelong integrity.
     * **Svargarohanika Parva:** Transcendence, reconciliation, and divine grace.

3. **Empathetic Counsel or Appreciation:**
   * If you faced setbacks, anxiety, or tough decisions: delivers warm, strategic counsel to navigate the dilemma.
   * If you achieved a victory, upheld truth, or practiced self-discipline: delivers genuine appreciation and reinforcement of your Dharma.

4. **Authentic Krishna Quotes & Gita Slokas:**
   * Illuminated card with original Sanskrit transliteration, English translation, and a practical modern takeaway.

5. **100% Private, Offline & Serverless:**
   * Works directly by double-clicking `index.html` (via `file:///`).
   * No backend, no accounts, no trackers, no external APIs.
   * All reflections are stored safely on your own machine in `localStorage`.

---

## How to Run

1. Open your File Explorer.
2. Navigate to:
   ```text
   Downloads / 3D_Railway_Simulator (1) / dharma-diary
   ```
3. **Double-click `index.html`**.
4. It will immediately open in your browser. Write an entry and click **CONSULT THE DHARMA ORACLE & REFLECT**.
