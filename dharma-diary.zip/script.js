/**
 * ==========================================================================
 * DHARMA DIARY: The 18 Parvas & Life Strategy Journal
 * High-Definition Visuals, Positive Affirmations & Synthesized Temple Bell
 * Pure Vanilla JavaScript (ES6) - Zero Dependencies - Offline & File:// Ready
 * ==========================================================================
 */

(function () {
  'use strict';

  // ---------------------------------------------------------------------------
  // 1. POSITIVE AFFIRMATIONS & BLESSINGS
  // ---------------------------------------------------------------------------
  const AFFIRMATIONS = [
    "You are never alone; the divine charioteer guides your conscience and every righteous step.",
    "Your duty is your sacred prayer. Pour your heart into the action; release all anxiety about results.",
    "The toughest battles are given to the strongest warriors. Arise, conquer your doubts, and shine.",
    "Peace is not the absence of external challenges, but the presence of Sri Krishna's calm within you.",
    "Even the mighty sun rises slowly from the darkness. Have patience with your personal growth.",
    "Righteous action (Dharma) protects those who protect it. Walk truthfully and fear nothing.",
    "When clarity fades, breathe and remember: your soul is eternal, untouched by temporary storms."
  ];

  // ---------------------------------------------------------------------------
  // 2. THE 18 PARVAS OF MAHABHARATA KNOWLEDGE BASE
  // ---------------------------------------------------------------------------
  const PARVAS_DB = [
    {
      id: 1,
      number: "I",
      name: "Adi Parva",
      englishTitle: "The Book of Beginnings & Seeds of Destiny",
      archetype: "Foundations, identity, seed of potential, fresh starts",
      epicContext: "Narrates the lineage of the Bharatas, the birth of the Pandavas and Kauravas, the palace of lac, and Arjuna winning Draupadi. It reminds us that every grand destiny begins with humble, courageous choices.",
      keywords: ["start", "begin", "new", "birth", "origin", "family", "childhood", "identity", "root", "foundation", "commence", "project", "dream", "career start", "ambition", "potential", "fresh"],
      moods: ["Hopeful", "Determined", "Peaceful"],
      advice: "Every mighty banyan tree begins as an imperceptible seed in the dark earth. Do not be disheartened if your beginnings feel modest or uncertain. Plant your intentions in the soil of truth (Satya), water them with steady discipline, and remember that how you begin sets the spiritual direction for the entire journey.",
      appreciation: "You are standing at the threshold of a noble beginning! Your clarity in acknowledging your origins and setting high intentions mirrors the young Pandavas stepping into their destiny. Cherish this morning of your journey with immense pride.",
      krishnaQuote: {
        verse: "aham ātmā guḍākeśa sarva-bhūtāśaya-sthitaḥ | aham ādiś ca madhyaṁ ca bhūtānām anta eva ca ||",
        source: "Bhagavad Gita 10.20",
        translation: "I am the Self, O Gudakesha (Arjuna), seated in the hearts of all living beings. I am the origin, the middle, and the end of all existence.",
        takeaway: "Trust that the divine spark within you initiates all good things. You are stepping forward with infinite cosmic support."
      }
    },
    {
      id: 2,
      number: "II",
      name: "Sabha Parva",
      englishTitle: "The Book of the Assembly Hall & Illusion",
      archetype: "Peer pressure, ego, gambling with values, toxic competition",
      epicContext: "The construction of the glorious palace of Indraprastha, followed by the fateful dice game where Yudhishthira, lured by pride and social challenge, temporarily lost his kingdom and honor.",
      keywords: ["gamble", "loss", "betrayal", "peer pressure", "ego", "pride", "regret", "foolish", "compete", "cheated", "unfair", "trapped", "addiction", "money", "mistake", "guilt", "envy"],
      moods: ["Overwhelmed", "Conflicted"],
      advice: "The dice game of life tempts us when pride whispers that we cannot walk away. If you have stumbled, made a poor calculation, or felt drawn into an unfair contest, stop the game immediately. Regret is not meant to paralyze you—it is an alarm warning you to step back from the hall of illusions.",
      appreciation: "You possess the rare courage to look honestly at your slip-ups and illusions without blaming the world. Acknowledging a misstep is the first victory of Dharma over ego.",
      krishnaQuote: {
        verse: "dhyāyato viṣayān puṁsaḥ saṅgas teṣūpajāyate | saṅgāt sañjāyate kāmaḥ kāmāt krodho 'bhijāyate ||",
        source: "Bhagavad Gita 2.62",
        translation: "Brooding over objects of the senses causes attachment; from attachment arises desire; and from unfulfilled desire, anger and confusion are born.",
        takeaway: "Notice where your mind is getting caught in toxic comparisons. Detach before the dice are thrown."
      }
    },
    {
      id: 3,
      number: "III",
      name: "Vana Parva",
      englishTitle: "The Book of the Forest & Resilience",
      archetype: "Exile, patience, waiting for your season, solitude, learning in hardship",
      epicContext: "The Pandavas spend twelve years in the wilderness. Instead of wallowing in despair, Arjuna acquires celestial astras, Yudhishthira masters self-control, and they learn from great sages.",
      keywords: ["lonely", "alone", "waiting", "exile", "struggle", "patience", "hardship", "isolated", "forest", "downtime", "training", "rejection", "unnoticed", "slow", "endurance", "routine"],
      moods: ["Overwhelmed", "Peaceful"],
      advice: "The forest is not an exile from your life; it is the sacred forge where your spirit is tempered. When the world ignores you, take it as an invitation from destiny to build inner mastery, read deeply, train your skills, and cultivate patience. The season of harvest always follows the season of quiet roots.",
      appreciation: "Your quiet endurance through this dry, solitary stretch is magnificent. Like the Pandavas in the forest, you are turning a period of trial into a period of profound spiritual self-elevation.",
      krishnaQuote: {
        verse: "uddhared ātmanātmānaṁ nātmānam avasādayet | ātmaiva hy ātmano bandhur ātmaiva ripur ātmanaḥ ||",
        source: "Bhagavad Gita 6.5",
        translation: "Elevate yourself through the power of your mind, and do not degrade yourself. For the mind can be your greatest friend or your most relentless adversary.",
        takeaway: "In moments of quiet isolation, choose to be your own steadfast ally."
      }
    },
    {
      id: 4,
      number: "IV",
      name: "Virata Parva",
      englishTitle: "The Book of Disguise & Modesty",
      archetype: "Staying undercover, humility, being underestimated, silent contribution",
      epicContext: "The thirteenth year of exile spent in disguise at the court of King Virata. The mighty Pandavas serve humbly as cooks, dance masters, and stables-men without revealing their royal identity.",
      keywords: ["humble", "underestimated", "disguise", "secret", "quiet", "unappreciated", "job", "office", "ego check", "modesty", "patiently", "waiting", "undervalued", "low profile"],
      moods: ["Peaceful", "Conflicted"],
      advice: "A true diamond does not lose its luster simply because it is wrapped in burlap. If you feel unacknowledged, underemployed, or underestimated in your current environment, work with quiet dignity. Great warriors know when to put down their royal armor and master the kitchen of life. Your moment to step into the light is coming.",
      appreciation: "You have shown exceptional grace and humility today. To do your work diligently without begging for applause requires the heart of a true sage.",
      krishnaQuote: {
        verse: "yoga-sthaḥ kuru karmāṇi saṅgaṁ tyaktvā dhanañjaya | siddhy-asiddhyoḥ samo bhūtvā samatvaṁ yoga ucyate ||",
        source: "Bhagavad Gita 2.48",
        translation: "Be steadfast in yoga, O Arjuna. Perform your duty without selfish attachment, remaining balanced in both success and failure. Equanimity is yoga.",
        takeaway: "Your worth is not validated by titles or applause; it is anchored in your poised execution."
      }
    },
    {
      id: 5,
      number: "V",
      name: "Udyoga Parva",
      englishTitle: "The Book of Effort, Peace & Preparation",
      archetype: "Diplomacy before battle, preparing for major crossroads, peaceful negotiation",
      epicContext: "Intense preparations for conflict. Sri Krishna goes in person as a peace envoy to Hastinapur to prevent war, seeking every path of non-violence until all peaceful avenues are exhausted.",
      keywords: ["preparation", "meeting", "exam", "interview", "decision", "negotiate", "peace", "diplomacy", "resolve", "conflict", "ready", "effort", "talking", "conversation", "future"],
      moods: ["Determined", "Conflicted"],
      advice: "Never launch into war—whether an argument, a lawsuit, or a confrontation—until you have exhausted every avenue of peace and understanding. Preparation is not just gathering weapons; it is clarifying your conscience. Offer peace sincerely. If conflict remains unavoidable, fight without hatred.",
      appreciation: "Your maturity in attempting diplomacy, dialogue, and thorough preparation before jumping to anger reflects the divine peacemaking of Sri Krishna in the Kaurava court.",
      krishnaQuote: {
        verse: "karmaṇy evādhikāras te mā phaleṣu kadācana | mā karma-phala-hetur bhūr mā te saṅgo 'stv akarmaṇi ||",
        source: "Bhagavad Gita 2.47",
        translation: "You have an absolute right to perform your prescribed duties, but never to the fruits of action. Never let outcomes be your motive, nor be attached to inaction.",
        takeaway: "Pour 100% of your energy into preparation and right conduct; leave the fruits in the hands of the cosmos."
      }
    },
    {
      id: 6,
      number: "VI",
      name: "Bhishma Parva",
      englishTitle: "The Book of Inner Duty & Moral Dilemmas",
      archetype: "The battlefield of the mind, Arjuna's doubt, conscience vs emotion",
      epicContext: "The grand battle begins on Kurukshetra. Arjuna is paralyzed seeing his grandfather Bhishma and teacher Drona. Krishna sings the immortal Bhagavad Gita to awaken his soul to Dharma.",
      keywords: ["confused", "dilemma", "moral", "right or wrong", "paralyzed", "family vs duty", "doubt", "fear", "anxiety", "can't decide", "battlefield", "mind", "conscience", "values"],
      moods: ["Conflicted", "Overwhelmed"],
      advice: "Whenever you feel torn between what is comfortable and what is righteous, you are standing in the chariot between the armies. Do not run away from your duty because your heart aches. A doctor must operate even when blood is shed; a truthful person must speak even when voice trembles. Listen to the Krishna within your conscience.",
      appreciation: "You are questioning your actions deeply rather than operating on blind autopilot. This divine crisis of conscience is exactly where Arjuna's spiritual awakening began.",
      krishnaQuote: {
        verse: "klaibyaṁ mā sma gamaḥ pārtha naitat tvayy upapadyate | kṣudraṁ hṛdaya-daurbalyaṁ tyaktvottiṣṭha paran-tapa ||",
        source: "Bhagavad Gita 2.3",
        translation: "Do not yield to cowardice or self-pity, O Arjuna; it does not befit you. Shake off this petty faint-heartedness and arise, scorcher of enemies!",
        takeaway: "Cast aside your paralysis. Stand up for the truth with dignified resolve."
      }
    },
    {
      id: 7,
      number: "VII",
      name: "Drona Parva",
      englishTitle: "The Book of Strategic Breakthroughs & Trials",
      archetype: "Overwhelming odds, Chakravyuha, standing alone, courage in pressure",
      epicContext: "Drona forms the impenetrable Chakravyuha. Young Abhimanyu fights with matchless valor and sacrifices his life. The battle tests every reserve of courage and strategic resolve.",
      keywords: ["pressure", "overwhelmed", "deadline", "heavy", "intense", "attack", "chakravyuha", "trapped", "standing alone", "brave", "fight", "odds", "grief", "young", "sacrifice"],
      moods: ["Overwhelmed", "Determined"],
      advice: "When life traps you in a complex formation where all sides seem blocked, remember Abhimanyu: his glory was not that he exited, but that he entered without fear and fought with supreme dignity. Break the problem into small, single-step decisions. Do not look at the entire army at once—deal with the step in front of you.",
      appreciation: "You have exhibited fierce courage in facing high-pressure demands today. Even when the odds felt unfair, your spirit did not surrender.",
      krishnaQuote: {
        verse: "sukha-duḥkhe same kṛtvā lābhālābhau jayājayau | tato yuddhāya yujyasva naivaṁ pāpam avāpsyasi ||",
        source: "Bhagavad Gita 2.38",
        translation: "Treat pleasure and pain, gain and loss, victory and defeat with equanimity; and then engage in your battle. Doing so, you will incur no sin.",
        takeaway: "Meet life's hardest tests with unconditional inner dignity."
      }
    },
    {
      id: 8,
      number: "VIII",
      name: "Karna Parva",
      englishTitle: "The Book of Destiny, Loyalty & Character",
      archetype: "Unlucky circumstances, self-worth, loyalty to flawed causes, talent",
      epicContext: "The climactic duel between Arjuna and Karna. Karna's chariot wheel gets stuck in the mud, reflecting how talent unsupported by Dharma ultimately falters.",
      keywords: ["unlucky", "bad luck", "destiny", "fate", "talent", "loyalty", "friend", "unfair", "stuck", "frustrated", "reputation", "rival", "past baggage", "cursed", "effort wasted"],
      moods: ["Conflicted", "Overwhelmed"],
      advice: "Skill and talent are divine gifts, but without ethical alignment, they cannot save you when the wheel gets stuck in the mud. Check your allegiances: are you fighting for what is right, or merely defending your wounded ego and old loyalties? Align with righteousness, and no mud can hold your chariot down.",
      appreciation: "Your heart carries immense loyalty and sensitivity. Channel your formidable abilities toward that which uplifts people rather than merely proving someone wrong.",
      krishnaQuote: {
        verse: "yatra yogeśvaraḥ kṛṣṇo yatra pārtho dhanur-dharaḥ | tatra śrīr vijayo bhūtir dhruvā nītir matir mama ||",
        source: "Bhagavad Gita 18.78",
        translation: "Wherever there is Krishna, the Lord of Yoga, and wherever there is Arjuna, the wielder of the bow, there will surely be fortune, victory, and unwavering morality.",
        takeaway: "Pair your human talent (the bow) with divine wisdom (Krishna), and victory is guaranteed."
      }
    },
    {
      id: 9,
      number: "IX",
      name: "Shalya Parva",
      englishTitle: "The Book of the Final Reckoning & Exhaustion",
      archetype: "The final stretch, fatigue near the finish line, confronting stubborn ego",
      epicContext: "Duryodhana hides under the waters of Dwaipayana lake. Bhima fights him in the mace duel. The war concludes, but both sides are exhausted.",
      keywords: ["tired", "exhausted", "almost done", "finish line", "stubborn", "final", "anger", "climax", "confrontation", "last lap", "end of project", "burned out", "fatigue"],
      moods: ["Overwhelmed", "Determined"],
      advice: "The final mile is always the most exhausting because you are no longer fighting the problem—you are fighting your own fatigue and stubborn ego. Do not hide in the waters of procrastination or denial. Breathe deeply, ground yourself, and take the final steps with clean sportsmanship.",
      appreciation: "You have pushed through deep mental and physical tiredness today. You are at the threshold of completion—stay centered and cross the line with honor.",
      krishnaQuote: {
        verse: "asaṁśayaṁ mahā-bāho mano durnigrahaṁ calam | abhyāsena tu kaunteya vairāgyeṇa ca gṛhyate ||",
        source: "Bhagavad Gita 6.35",
        translation: "Undoubtedly, O mighty-armed one, the mind is restless and difficult to curb. But through steady practice (abhyasa) and detachment (vairagya), it is brought under control.",
        takeaway: "Master your restlessness near the finish line through calm, repetitive focus."
      }
    },
    {
      id: 10,
      number: "X",
      name: "Sauptika Parva",
      englishTitle: "The Book of the Night Raid & Unfair Blows",
      archetype: "Attacked while resting, betrayal, underhanded hits, resisting vengeance",
      epicContext: "Ashwatthama launches a nocturnal raid on the sleeping Pandava camp, killing their sons. Yudhishthira and Draupadi choose forgiveness over continuous blood feuds.",
      keywords: ["betrayed", "backstabbed", "cheated", "unfair", "night", "revenge", "bitter", "anger", "hurt", "trauma", "attacked", "stab in the back", "cruel", "toxic coworker", "lie"],
      moods: ["Overwhelmed", "Conflicted"],
      advice: "When someone hurts you dishonorably, your first instinct is to burn the world with vengeance. But vengeance is a poison you drink hoping the other person dies. Do not let another person's cruelty turn you into an Ashwatthama. Grieve the wound, set iron boundaries, but do not let bitterness rot your sacred heart.",
      appreciation: "Your restraint in refusing to sink to their level today is true heroism. The Pandavas conquered the earth, but Draupadi's forgiveness of Ashwatthama conquered the heavens.",
      krishnaQuote: {
        verse: "krodhād bhavati sammohaḥ sammohāt smṛti-vibhramaḥ | smṛti-bhraṁśād buddhi-nāśo buddhi-nāśāt praṇaśyati ||",
        source: "Bhagavad Gita 2.63",
        translation: "From anger arises delusion; from delusion, confusion of memory; from corrupted memory, the destruction of intellect; and from loss of intellect, a person is completely ruined.",
        takeaway: "Quench the fire of anger with the cool water of discernment before it destroys your inner peace."
      }
    },
    {
      id: 11,
      number: "XI",
      name: "Stri Parva",
      englishTitle: "The Book of Grief, Lamentation & Healing",
      archetype: "Mourning loss, tears, processing human vulnerability, empathy",
      epicContext: "Gandhari, Kunti, and the women of Hastinapur survey the battlefield and mourn the fallen. Gandhari's grief and tears lead to understanding the profound tragedy of hatred.",
      keywords: ["sad", "crying", "grief", "loss", "tears", "mourning", "pain", "broken", "death", "heartbroken", "vulnerable", "heal", "sorrow", "regret", "depressed"],
      moods: ["Overwhelmed", "Peaceful"],
      advice: "Tears are not a sign of weakness; they are the soul's natural cleansing water. When loss strikes, do not rush to be strong or philosophize the pain away. Sit with your grief, wrap yourself in compassion, and remember that everyone around you is carrying invisible sorrows.",
      appreciation: "Your willingness to feel your emotions deeply and acknowledge vulnerability shows a tender, mature soul. Healing begins when we stop pretending we cannot hurt.",
      krishnaQuote: {
        verse: "vāsāṁsi jīrṇāni yathā vihāya navāni gṛhṇāti naro 'parāṇi | tathā śarīrāṇi vihāya jīrṇāny anyāni saṁyāti navāni dehī ||",
        source: "Bhagavad Gita 2.22",
        translation: "Just as a person casts off worn-out garments and puts on new ones, so the embodied soul casts off worn-out bodies and enters new ones.",
        takeaway: "Trust that while forms and seasons pass away, the love and eternal soul within never die."
      }
    },
    {
      id: 12,
      number: "XII",
      name: "Shanti Parva",
      englishTitle: "The Book of Peace, Governance & Wisdom",
      archetype: "Restorative calm, elder mentorship, self-mastery, ethics, inner silence",
      epicContext: "Bhishma lies on the bed of arrows and imparts exhaustive discourses on ethics, statecraft, detachment, and liberation to Yudhishthira, soothing his troubled soul.",
      keywords: ["peace", "calm", "wisdom", "mentor", "advice", "learning", "study", "ethics", "quiet", "meditation", "balance", "rest", "healing", "clarity", "philosophy"],
      moods: ["Peaceful", "Grateful"],
      advice: "Cherish this quiet lake of tranquility. True peace is not the absence of storms outside, but the presence of stillness inside. Absorb wisdom from teachers, books, and nature, and cultivate the mental reservoir that will keep you steady when future winds blow.",
      appreciation: "You have cultivated a beautiful state of balance and thoughtful reflection today. Your mind is like a clear autumn lake, reflecting the sky without disturbance.",
      krishnaQuote: {
        verse: "vihāya kāmān yaḥ sarvān pumāṁś carati niḥspṛhaḥ | nirmamo nirahaṅkāro sa śāntim adhigacchati ||",
        source: "Bhagavad Gita 2.71",
        translation: "That person who relinquishes all personal desires, moving about free from craving, free from possessiveness and ego, attains true peace.",
        takeaway: "Let go of the need to control everything; peace is found in release."
      }
    },
    {
      id: 13,
      number: "XIII",
      name: "Anushasana Parva",
      englishTitle: "The Book of Daily Discipline & Ethical Habits",
      archetype: "Habits, daily discipline, charity, kindness to beings, building good karma",
      epicContext: "Bhishma continues his final instructions on Dana (charity), Ahimsa (non-harming), daily prayers, dietary purity, and the 1000 names of Vishnu (Vishnu Sahasranama).",
      keywords: ["discipline", "routine", "habit", "charity", "kindness", "helping", "diet", "clean", "good karma", "giving", "respect", "parents", "worship", "consistency", "health"],
      moods: ["Peaceful", "Determined"],
      advice: "Destiny is not carved by lightning strikes of inspiration; it is built with the quiet chisel of daily habits. How you speak to someone serving you, how you honor your word, and how you care for your body are the true prayers of your life. Keep your small promises to yourself.",
      appreciation: "Your commitment to steady discipline and acts of quiet kindness today creates ripples of positive karma that will protect your future steps.",
      krishnaQuote: {
        verse: "anudvega-karaṁ vākyaṁ satyaṁ priya-hitaṁ ca yat | svādhyāyābhyasanaṁ caiva vāṅ-mayaṁ tapa ucyate ||",
        source: "Bhagavad Gita 17.15",
        translation: "Words that cause no distress, which are truthful, pleasant, and beneficial, combined with the regular study of wisdom, are declared the austerity of speech.",
        takeaway: "Speak gently, act honestly, and cultivate habits that bring peace to others."
      }
    },
    {
      id: 14,
      number: "XIV",
      name: "Ashwamedhika Parva",
      englishTitle: "The Book of Rebuilding & Spiritual Rebirth",
      archetype: "Starting over after a crisis, self-conquest, renewal of purpose",
      epicContext: "Yudhishthira performs the sacred Ashwamedha sacrifice to heal the land. Arjuna traverses all kingdoms once more, this time reconciling former foes and rebuilding unity.",
      keywords: ["rebuild", "fresh start", "restart", "recovery", "forgive", "renew", "healing", "strength", "moving forward", "second chance", "redemption", "confidence back"],
      moods: ["Determined", "Hopeful", "Grateful"],
      advice: "Do not gaze backward at the ruins of what fell apart. You cannot build a new temple using old ashes. Forgive those who fell, forgive yourself for past stumbles, and invest your fresh energy into creating something worthy, noble, and beautiful.",
      appreciation: "You are rising from a difficult chapter with fresh vigor and dignity! Like Arjuna riding with the sacrificial steed, you are reclaiming your rightful strength.",
      krishnaQuote: {
        verse: "tasmād asaktaḥ satataṁ kāryaṁ karma samācara | asakto hy ācaran karma param āpnoti pūruṣaḥ ||",
        source: "Bhagavad Gita 3.19",
        translation: "Therefore, free from selfish craving, constantly perform the work that needs to be done. For by performing duty without attachment, one attains the highest realization.",
        takeaway: "Focus completely on today's rebuilding; the future will take care of itself."
      }
    },
    {
      id: 15,
      number: "XV",
      name: "Ashramavasika Parva",
      englishTitle: "The Book of Graceful Transition & Detachment",
      archetype: "Handing over power, stepping back, retirement, letting go of control",
      epicContext: "Old King Dhritarashtra, Gandhari, and Kunti decide to retire to the hermitages in the forest, peacefully handing over Hastinapur to the younger generation.",
      keywords: ["letting go", "moving on", "retire", "transition", "pass the torch", "step down", "handover", "graduating", "new chapter", "leaving", "empty nest", "detachment"],
      moods: ["Peaceful", "Grateful"],
      advice: "There is a season to hold the reins, and a season to gracefully let them go. Do not cling to roles or arguments that have expired. Trust that the seeds you planted will grow under new caretakers, and grant yourself permission to step into lighter, quieter pastures.",
      appreciation: "You have shown immense maturity in allowing things to evolve and stepping back without bitterness. Letting go is the crowning jewel of inner mastery.",
      krishnaQuote: {
        verse: "tyaktvā karma-phalāsaṅgaṁ nitya-tṛpto nirāśrayaḥ | karmaṇy abhipravṛtto 'pi naiva kiñcit karoti saḥ ||",
        source: "Bhagavad Gita 4.20",
        translation: "Having abandoned attachment to results, always contented and self-reliant, such a person does not incur binding karma even while engaged in action.",
        takeaway: "True freedom is being thoroughly engaged without needing to own the outcome."
      }
    },
    {
      id: 16,
      number: "XVI",
      name: "Mausala Parva",
      englishTitle: "The Book of Impermanence & Humility",
      archetype: "Fall of empires, the fleeting nature of luxury, reality check",
      epicContext: "The Yadava clan, blinded by luxury, power, and mutual arrogance, destroys itself in internal strife. Dwarka sinks into the ocean. Krishna departs, proving all worldly glory passes.",
      keywords: ["pride", "arrogance", "fall", "materialistic", "change", "nothing lasts", "shock", "humility", "money isn't everything", "impermanence", "vanity", "reality check"],
      moods: ["Overwhelmed", "Conflicted"],
      advice: "When you observe wealth, beauty, power, or friendships crumbling around you, do not sink into cynicism. Recognize it as the cosmic reminder that no material fortress stands forever. Build your identity on values that cannot drown in the sea.",
      appreciation: "Your realization of life's impermanence is a profound spiritual turning point. It protects you from the intoxication of pride and the despair of loss.",
      krishnaQuote: {
        verse: "mātrā-sparśās tu kaunteya śītoṣṇa-sukha-duḥkha-dāḥ | āgamāpāyino 'nityās tāṁs titikṣasva bhārata ||",
        source: "Bhagavad Gita 2.14",
        translation: "Contacts of the senses with their objects produce sensations of heat and cold, pleasure and pain. They come and go, being temporary. Learn to endure them with patience, O Bharata.",
        takeaway: "Treat both glory and setbacks as temporary weather passing through your sky."
      }
    },
    {
      id: 17,
      number: "XVII",
      name: "Mahaprasthanika Parva",
      englishTitle: "The Book of the Final Ascent & Loyalty",
      archetype: "Lifelong perseverance, walking alone for truth, loyalty till the peak",
      epicContext: "The Pandavas undertake their final journey up Mount Meru. One by one, their companions fall due to subtle character flaws. Only Yudhishthira reaches the summit, accompanied by a loyal stray dog.",
      keywords: ["lonely path", "integrity", "standing alone", "dog", "loyalty", "faithful", "perseverance", "values", "hiking", "journey", "peak", "truth", "uncompromising"],
      moods: ["Determined", "Peaceful"],
      advice: "When you walk the path of pure truth, you may sometimes find yourself walking alone. People may drop away because of their own desires and attachments. Do not compromise your moral compass to keep casual company. Stand by your values, cherish the humble beings who stay truly loyal, and keep climbing.",
      appreciation: "Your refusal to compromise your integrity, even when doing so felt lonely, is the very hallmark of Yudhishthira standing on Mount Meru with his faithful companion. Honor your noble heart.",
      krishnaQuote: {
        verse: "kṣipraṁ bhavati dharmātmā śaśvac-chāntiṁ nigacchati | kaunteya pratijānīhi na me bhaktaḥ praṇaśyati ||",
        source: "Bhagavad Gita 9.31",
        translation: "Quickly they become righteous and attain everlasting peace. Proclaim it boldly, O son of Kunti, that my devotee never perishes.",
        takeaway: "Walk with righteousness; the divine universe guarantees that your integrity will never be lost."
      }
    },
    {
      id: 18,
      number: "XVIII",
      name: "Svargarohanika Parva",
      englishTitle: "The Book of Transcendence, Reconciliation & Grace",
      archetype: "Ultimate harmony, forgiving foes, seeing the higher divine plan, grace",
      epicContext: "Yudhishthira enters the heavenly realm. After passing through a final test of illusion, he sees his brothers, Draupadi, and even the Kauravas seated in radiant harmony, free from all mortal hatred.",
      keywords: ["gratitude", "forgiveness", "harmony", "peace of mind", "victory", "spiritual", "transcend", "blessed", "relief", "love", "unity", "grace", "understanding", "joy"],
      moods: ["Grateful", "Triumphant", "Peaceful"],
      advice: "Rejoice in this elevated state of consciousness. When you can look at past enemies, hardships, and tears with understanding and forgiveness, you have reached heaven on earth. Spread this light generously to everyone you meet.",
      appreciation: "Your heart is filled with pure gratitude, forgiveness, and elevated peace today. You have conquered not just the outer world, but the inner world of resentment.",
      krishnaQuote: {
        verse: "sarva-dharmān parityajya mām ekaṁ śaraṇaṁ vraja | ahaṁ tvāṁ sarva-pāpebhyo mokṣayiṣyāmi mā śucaḥ ||",
        source: "Bhagavad Gita 18.66",
        translation: "Abandon all varieties of fear, anxiety, and rigid burdens; surrender unto Me alone. I shall deliver you from all sorrow and tribulations. Grieve no more.",
        takeaway: "Rest in the sanctuary of divine grace. You are held, guided, and deeply loved."
      }
    }
  ];

  // ---------------------------------------------------------------------------
  // 3. SYNTHESIZED MEDITATIVE TEMPLE CHIME (Web Audio API - 0 Files)
  // ---------------------------------------------------------------------------
  class SacredSoundEngine {
    static playBell() {
      try {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (!AudioCtx) return;
        const ctx = new AudioCtx();

        // Fundamental frequencies of Tibetan/Temple bell
        const freqs = [528, 1056, 1584, 2112];
        const now = ctx.currentTime;

        freqs.forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();

          osc.type = "sine";
          osc.frequency.setValueAtTime(freq + (Math.random() - 0.5) * 4, now);

          const initialGain = 0.25 / (idx + 1);
          gain.gain.setValueAtTime(initialGain, now);
          gain.gain.exponentialRampToValueAtTime(0.0001, now + 3.5);

          osc.connect(gain);
          gain.connect(ctx.destination);

          osc.start(now);
          osc.stop(now + 3.6);
        });
      } catch (e) {
        console.log("Audio not supported or permitted yet.");
      }
    }
  }

  // ---------------------------------------------------------------------------
  // 4. PARVA SEMANTIC & SENTIMENT ANALYZER ENGINE
  // ---------------------------------------------------------------------------
  class DharmaOracle {
    static analyzeEntry(text, mood, domain) {
      const clean = text.toLowerCase();
      let best = PARVAS_DB[0];
      let maxScore = -1;

      // Positive sentiment signals
      const triumphWords = ["won", "succeeded", "happy", "blessed", "gratitude", "achieved", "celebrate", "proud", "peaceful", "completed", "passed", "finished", "joy", "loved", "smile"];
      const isPositive = triumphWords.some(w => clean.includes(w)) || mood === "Triumphant" || mood === "Grateful" || mood === "Peaceful";

      PARVAS_DB.forEach(parva => {
        let score = 0;

        // Keyword matches (+3)
        parva.keywords.forEach(kw => {
          if (clean.includes(kw)) score += 3;
        });

        // Mood affinity (+4)
        if (parva.moods.includes(mood)) score += 4;

        // Domain affinity
        if (domain === "Ethical Dilemma" && (parva.id === 6 || parva.id === 2 || parva.id === 17)) score += 4;
        if (domain === "Career & Studies" && (parva.id === 5 || parva.id === 7 || parva.id === 4)) score += 3;
        if (domain === "Relationships" && (parva.id === 2 || parva.id === 10 || parva.id === 18)) score += 3;
        if (domain === "Inner Peace" && (parva.id === 12 || parva.id === 3 || parva.id === 18)) score += 4;
        if (domain === "Habits & Discipline" && (parva.id === 13 || parva.id === 1 || parva.id === 14)) score += 4;

        if (score > maxScore) {
          maxScore = score;
          best = parva;
        }
      });

      const isAppreciation = isPositive && !clean.includes("grief") && !clean.includes("sad");
      const counselText = isAppreciation ? best.appreciation : best.advice;
      const counselTitle = isAppreciation ? "✨ Sacred Appreciation & Affirmation" : "🕊️ Sri Krishna's Strategic Counsel & Guidance";

      return {
        parva: best,
        isAppreciation: isAppreciation,
        counselTitle: counselTitle,
        counselText: counselText,
        quote: best.krishnaQuote
      };
    }
  }

  // ---------------------------------------------------------------------------
  // 5. LOCAL STORAGE REPOSITORY
  // ---------------------------------------------------------------------------
  const STORAGE_KEY = "dharma_diary_entries_v2";

  class DiaryRepository {
    static getAll() {
      try {
        const raw = localStorage.getItem(STORAGE_KEY);
        return raw ? JSON.parse(raw) : [];
      } catch (e) {
        return [];
      }
    }

    static save(entry) {
      const all = DiaryRepository.getAll();
      all.unshift(entry);
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
      } catch (e) {}
      return all;
    }

    static delete(id) {
      const remaining = DiaryRepository.getAll().filter(item => item.id !== id);
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(remaining));
      } catch (e) {}
      return remaining;
    }
  }

  // ---------------------------------------------------------------------------
  // 6. UI CONTROLLER & EVENT INITIALIZATION
  // ---------------------------------------------------------------------------
  function initializeApp() {
    const affirmationEl = document.getElementById("dailyAffirmationText");
    const currentDatePill = document.getElementById("currentDatePill");
    const moodChips = document.querySelectorAll(".mood-chip");
    const domainSelect = document.getElementById("domainSelect");
    const journalInput = document.getElementById("journalInput");
    const btnConsultOracle = document.getElementById("btnConsultOracle");
    const btnChantBell = document.getElementById("btnChantBell");

    // Revelation Card Elements
    const revelationContainer = document.getElementById("revelationContainer");
    const revParvaNumber = document.getElementById("revParvaNumber");
    const revParvaTitle = document.getElementById("revParvaTitle");
    const revParvaArchetype = document.getElementById("revParvaArchetype");
    const revEpicContext = document.getElementById("revEpicContext");
    const counselAlertBox = document.getElementById("counselAlertBox");
    const counselTitleText = document.getElementById("counselTitleText");
    const counselBodyText = document.getElementById("counselBodyText");
    const verseSourceTag = document.getElementById("verseSourceTag");
    const sanskritVerseText = document.getElementById("sanskritVerseText");
    const englishVerseText = document.getElementById("englishVerseText");
    const practicalTakeawayTag = document.getElementById("practicalTakeawayTag");

    // History & Search
    const journalHistoryGrid = document.getElementById("journalHistoryGrid");
    const journalSearchInput = document.getElementById("journalSearchInput");

    // Modal
    const parvasLibraryModal = document.getElementById("parvasLibraryModal");
    const btnExploreParvas = document.getElementById("btnExploreParvas");
    const btnCloseLibraryModal = document.getElementById("btnCloseLibraryModal");
    const parvasCatalogGrid = document.getElementById("parvasCatalogGrid");

    let currentMood = "Determined";

    // Set Auspicious Date
    const now = new Date();
    const formattedDate = now.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric"
    });
    if (currentDatePill) currentDatePill.textContent = formattedDate;

    // Cycle Positive Affirmations
    let affIndex = 0;
    setInterval(() => {
      affIndex = (affIndex + 1) % AFFIRMATIONS.length;
      if (affirmationEl) {
        affirmationEl.style.opacity = 0;
        setTimeout(() => {
          affirmationEl.textContent = `"${AFFIRMATIONS[affIndex]}"`;
          affirmationEl.style.opacity = 1;
        }, 300);
      }
    }, 9000);

    // Temple Bell Sound
    if (btnChantBell) {
      btnChantBell.addEventListener("click", () => {
        SacredSoundEngine.playBell();
        btnChantBell.innerHTML = "<span>✨</span> Chime Played";
        setTimeout(() => {
          btnChantBell.innerHTML = "<span>🔔</span> Play Temple Chime";
        }, 1800);
      });
    }

    // Mood Selector Chips
    moodChips.forEach(chip => {
      chip.addEventListener("click", () => {
        moodChips.forEach(c => c.classList.remove("active"));
        chip.classList.add("active");
        currentMood = chip.getAttribute("data-mood");
      });
    });

    // Populate Modal Catalog
    if (parvasCatalogGrid) {
      parvasCatalogGrid.innerHTML = PARVAS_DB.map(p => `
        <div class="parva-tile">
          <span class="parva-tile-num">Parva ${p.number} of XVIII</span>
          <h4 class="parva-tile-name">${p.name}</h4>
          <span style="font-size:0.82rem; color:var(--text-peacock); font-style:italic;">${p.englishTitle}</span>
          <p style="font-size:0.86rem; color:var(--text-muted); line-height:1.6; margin-top:4px;">${p.epicContext}</p>
        </div>
      `).join("");
    }

    // Modal Events
    if (btnExploreParvas && parvasLibraryModal) {
      btnExploreParvas.addEventListener("click", () => parvasLibraryModal.classList.add("active"));
    }
    if (btnCloseLibraryModal && parvasLibraryModal) {
      btnCloseLibraryModal.addEventListener("click", () => parvasLibraryModal.classList.remove("active"));
    }
    window.addEventListener("click", (e) => {
      if (e.target === parvasLibraryModal) parvasLibraryModal.classList.remove("active");
    });

    // Render History
    function renderHistory(query = "") {
      if (!journalHistoryGrid) return;
      const all = DiaryRepository.getAll();
      const q = query.trim().toLowerCase();

      const filtered = all.filter(item => {
        if (!q) return true;
        return (
          item.text.toLowerCase().includes(q) ||
          item.parvaName.toLowerCase().includes(q) ||
          item.mood.toLowerCase().includes(q) ||
          item.domain.toLowerCase().includes(q)
        );
      });

      if (filtered.length === 0) {
        journalHistoryGrid.innerHTML = `
          <div style="grid-column: 1 / -1; text-align: center; color: var(--text-dim); padding: 40px; font-style: italic;">
            ${all.length === 0 ? "Your sacred chronicle awaits. Write your first reflection above to connect with Sri Krishna and the 18 Parvas." : "No reflections matched your search."}
          </div>
        `;
        return;
      }

      journalHistoryGrid.innerHTML = filtered.map(item => `
        <div class="history-card">
          <div class="history-card-header">
            <span>${item.dateFormatted}</span>
            <span class="history-badge">${item.parvaName}</span>
          </div>
          <div style="display:flex; gap:8px; align-items:center;">
            <span style="font-size:0.85rem; color:var(--text-gold); font-weight:700;">${item.mood}</span>
            <span style="font-size:0.78rem; color:var(--text-dim);">• ${item.domain}</span>
          </div>
          <p class="history-snippet">"${escapeHtml(item.text)}"</p>
          <div class="history-footer">
            <span style="font-size:0.8rem; color:var(--text-muted); font-style:italic;">
              ${escapeHtml(item.quote.source)}
            </span>
            <button type="button" class="btn-trash" data-id="${item.id}" title="Delete reflection">🗑️</button>
          </div>
        </div>
      `).join("");

      // Bind delete
      document.querySelectorAll(".btn-trash").forEach(btn => {
        btn.addEventListener("click", (e) => {
          const id = e.currentTarget.getAttribute("data-id");
          if (confirm("Remove this entry from your sacred chronicle?")) {
            DiaryRepository.delete(id);
            renderHistory(journalSearchInput ? journalSearchInput.value : "");
          }
        });
      });
    }

    function escapeHtml(str) {
      if (!str) return "";
      return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
    }

    if (journalSearchInput) {
      journalSearchInput.addEventListener("input", (e) => {
        renderHistory(e.target.value);
      });
    }

    // Submit Reflection Handler
    if (btnConsultOracle) {
      btnConsultOracle.addEventListener("click", () => {
        const text = journalInput.value.trim();
        if (!text) {
          alert("Please write a few thoughts or reflections about your day first.");
          journalInput.focus();
          return;
        }

        const domain = domainSelect ? domainSelect.value : "General";

        // Play gentle chime on reflection
        SacredSoundEngine.playBell();

        // Analyze via Dharma Oracle
        const result = DharmaOracle.analyzeEntry(text, currentMood, domain);

        // Populate Revelation UI
        revParvaNumber.textContent = `Parva ${result.parva.number} of XVIII`;
        revParvaTitle.textContent = `${result.parva.name} — ${result.parva.englishTitle}`;
        revParvaArchetype.textContent = `Mirror of the Soul: ${result.parva.archetype}`;
        revEpicContext.textContent = `${result.parva.epicContext} Today, your reflection resonates with this chapter because it mirrors the timeless human journey of finding alignment, courage, and purpose amidst life's shifting battlefields.`;

        counselTitleText.innerHTML = result.counselTitle;
        counselBodyText.textContent = result.counselText;
        if (result.isAppreciation) {
          counselAlertBox.classList.add("appreciation");
        } else {
          counselAlertBox.classList.remove("appreciation");
        }

        verseSourceTag.textContent = result.quote.source;
        sanskritVerseText.textContent = `"${result.quote.verse}"`;
        englishVerseText.textContent = result.quote.translation;
        practicalTakeawayTag.textContent = `💡 Divine Action: ${result.quote.takeaway}`;

        // Reveal and scroll smoothly
        revelationContainer.style.display = "block";
        revelationContainer.scrollIntoView({ behavior: "smooth", block: "start" });

        // Save
        const newRecord = {
          id: "dharma_" + Date.now(),
          dateFormatted: formattedDate,
          timestamp: Date.now(),
          mood: currentMood,
          domain: domain,
          text: text,
          parvaName: result.parva.name,
          parvaNumber: result.parva.number,
          counsel: result.counselText,
          quote: result.quote
        };
        DiaryRepository.save(newRecord);
        renderHistory();
      });
    }

    // Initial load
    renderHistory();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initializeApp);
  } else {
    initializeApp();
  }
})();
